<?php $__env->startSection('main'); ?>
    <style>
       
    </style>
    <!-- end topbar -->
    <!-- dashboard inner -->
    <div class="midde_cont mt-2">
        <div class="container-fluid">
            <div class="row">
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            <span class="font-weight-bold ">Employee List</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row my-1">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered myTable ">
                                <thead>
                                    <th class="text-center">S.No</th>
                                    <th class="text-center">Emp ID</th>
                                    <th class="text-center">Emp Name</th>
                                    <th class="text-center">Date of Joining</th>
                                    <th class="text-center">Date of Retirement</th>
                                    <th class="text-center">Gender</th>
                                    <th class="text-center">Mobile No</th>
                                    <th class="text-center">Alternative No</th>
                                    
                                    <th class="text-center">Action</th>
                                    
                                    
                                </thead>

                                <tbody class="text-center">
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><a href="<?php echo e(route('employeDetails',$d->emp_id)); ?>" class="text-primary"><?php echo e($d->emp_id); ?></a></td>
                                            <td><?php echo e($d->name); ?></td>
                                            <td><?php echo e($d->do_joining); ?></td>
                                            <td><?php echo e($d->do_retirement); ?></td>
                                            
                                            <td><?php echo e($d->gender); ?></td>
                                            
                                            <td><?php echo e($d->primary_mob); ?></td>
                                            <td><?php echo e($d->alternat_mob); ?></td>
                                           
                                            
                                            <td>
                                                <a href="javascript:void(0)" class="text-success " data-id="<?php echo e($d->id); ?>"><i
                                                    class="fa fa-edit" aria-hidden="true"  ></i></a>
                                                <a href="javascript:void(0)" class="text-danger " data-id="<?php echo e($d->id); ?>"><i
                                                        class="fa fa-trash" aria-hidden="true"  ></i></a>
                                            </td>
                                        </tr>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>


                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- row -->


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Adityahrms1\govt_hrms\govt_hrms\hrms\hrmsproject\resources\views/employee/emplisting.blade.php ENDPATH**/ ?>