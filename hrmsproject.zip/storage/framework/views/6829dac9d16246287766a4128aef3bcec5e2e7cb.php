<?php echo $__env->make('employee.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('main'); ?>

<?php echo $__env->make('employee.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Adityahrms1\govt_hrms\govt_hrms\hrms\hrmsproject\resources\views/employee/layouts/main.blade.php ENDPATH**/ ?>