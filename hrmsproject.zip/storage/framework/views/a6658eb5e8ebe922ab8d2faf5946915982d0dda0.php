<?php $__env->startSection('main'); ?>

    <!-- end topbar -->
    <!-- dashboard inner -->
    <div class="midde_cont mt-2">
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                             <span class="font-weight-bold text-primary" style="font-size:15px">Unit Details Page</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row my-2">
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            <label class="font-weigh-bold text-success">Total Employee: <?php echo e(count($Employees)); ?></label>
                        </div>
                    </div>
                    
                </div>
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            <label class="font-weigh-bold text-primary">Total LTC Request: <?php echo e($ltc); ?></label>
                        </div>
                    </div>
                    
                </div>
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            <label class="font-weigh-bold text-danger">Total Medical Request: <?php echo e($mdcl); ?></label>
                        </div>
                    </div>
                    
                </div>
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            <label class="font-weigh-bold text-primary">Total CEA Request: <?php echo e($cea); ?></label>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="row my-1">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs d-none" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="tab" href="#basic_unitdetails" role="tab">Unit
                                        Details</a>
                                </li>
                                <li class="nav-item d-none">
                                    <a class="nav-link" data-toggle="tab" href="#dependent_details" role="tab">Dependent</a>
                                </li>
                                <li class="nav-item d-none">
                                    <a class="nav-link" data-toggle="tab" href="#bank_details" role="tab">Bank Details</a>
                                </li>
                                <li class="nav-item d-none">
                                    <a class="nav-link" data-toggle="tab" href="#pf_details" role="tab">PF Account</a>
                                </li>
                                
                                <li class="nav-item d-none">
                                    <a class="nav-link" data-toggle="tab" href="#emp_skills" role="tab">Skills</a>
                                </li>
                                <li class="nav-item d-none">
                                    <a class="nav-link" data-toggle="tab" href="#emp_job_history" role="tab">Job History</a>
                                </li>
                                <li class="nav-item d-none">
                                    <a class="nav-link " data-toggle="tab" href="#emp_apply_cghs" role="tab">CHGS</a>
                                </li>

                            </ul><!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="basic_unitdetails" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="add-new-unit-detail-form">
                                                <div class="row d-none">
                                                    <div class="col">
                                                        <label class="font-weight-bold">Add Unit Data</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row my-2">
                                                    <div class="col">
                                                        <label>Unit Name</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="empUnitName" value="<?php echo e(!empty($data->unit_name) ? $data->unit_name: 'Station Workshop EME'); ?>" placeholder="eg. Station Workshop EME" class="form-control" required>
                                                    </div>

                                                    <div class="col">
                                                        <label>Unit No/Code</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="empUnitNo" value="<?php echo e(!empty($data->unit_no) ? $data->unit_no: '3303'); ?>" placeholder="eg. 3303" class="form-control" required>
                                                    </div>
                                                    <div class="col">
                                                        <label>Unit Incharge</label><sup class="text-danger">*</sup>
                                                        <select class="empSearch" style="width:100% !important" name="unitInchg " id="unitInchg" required>
                                                            <option value="0">Select</option>
                                                                <?php $__currentLoopData = $Employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($data->unit_incharge_id==$emp->emp_id): ?>
                                                                <option value="<?php echo e($emp->name); ?>" selected><?php echo e($emp->name); ?> (
                                                                    <?php echo e($emp->emp_id); ?> )</option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($emp->name); ?>"><?php echo e($emp->name); ?> (
                                                                    <?php echo e($emp->emp_id); ?> )</option>
                                                                <?php endif; ?>
                                                                
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Unit Address</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="unitAddress" value="<?php echo e(!empty($data->unit_address) ? $data->unit_address: 'Delhi Cantt'); ?>" placeholder="eg. Delhi Cantt" class="form-control" required>
                                                    </div>
                                                    <div class="col">
                                                        <label>City</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="unitCity" value="<?php echo e(!empty($data->unit_city) ? $data->unit_city: 'New Delhi'); ?>" placeholder="eg. New Delhi" class="form-control" required>
                                                    </div>
                                                    <div class="col">
                                                        <label>Pin Code</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="unitPcode" value="<?php echo e(!empty($data->unit_pincode) ? $data->unit_pincode: '110010'); ?>" placeholder="eg. 110010" class="form-control" required>
                                                    </div>
                                                    
                                                   

                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>InCharge Designation</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="unitInchgDesig" value="<?php echo e(!empty($data->unit_incharge_Designation) ? $data->unit_incharge_Designation: 'AEE'); ?>" placeholder="eg. AEE" class="form-control" required>
                                                    </div>
                                                    <div class="col">
                                                        <label>Office Name</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="unitOfficename" value="C<?php echo e(!empty($data->unit_name) ? $data->unit_name: 'Station Workshop EME'); ?>iv Est officer" placeholder="eg. Civ Est officer" class="form-control" required>
                                                    </div>
                                                    
                                                   

                                                </div>
                                               
                                               
                                                <div class="row mt-4">
                                                    <div class="col">
                                                        <label class="font-weight-bold"> Contact Information</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Office Email</label>
                                                        <input type="email" name="ofcEmail" value="<?php echo e(!empty($data->unit_name) ? $data->unit_name: 'Station Workshop EME'); ?>" class="form-control">
                                                    </div>

                                                    <div class="col">
                                                        <label>Office Telephone No.</label><sup class="text-danger">*</sup>
                                                        <input type="text" name="ofcTpno" value="<?php echo e(!empty($data->unit_name) ? $data->unit_name: 'Station Workshop EME'); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col">
                                                        <label>Alternative No.</label>
                                                        <input type="text" name="ofcAlttNo" value="<?php echo e(!empty($data->unit_name) ? $data->unit_name: 'Station Workshop EME'); ?>" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Temporary Address</label>
                                                        <textarea name="empTempAddress" aria-valuemax="<?php echo e(!empty($data->unit_name) ? $data->unit_name: 'Station Workshop EME'); ?>" class="form-control"></textarea>
                                                    </div>
                                                </div>
                                                
                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <button type="Submit" class="btn btn-success">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                        
                                        
                                </div>
                               
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Adityahrms1\govt_hrms\govt_hrms\hrms\hrmsproject\resources\views/employee/unit_detailing.blade.php ENDPATH**/ ?>