<?php $__env->startSection('main'); ?>

    <!-- end topbar -->
    <!-- dashboard inner -->
    <div class="midde_cont mt-2">
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            Employee Deatils - <span class="font-weight-bold text-primary" style="font-size:15px"><?php echo e($data->name); ?> (<?php echo e($id); ?>)</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row my-1">
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="tab" href="#basic_details" role="tab">Basic
                                        Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#dependent_details" role="tab">Dependent</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#bank_details" role="tab">Bank Details</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#pf_details" role="tab">PF Account</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#emp_skills" role="tab">Skills</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#emp_job_history" role="tab">Job History</a>
                                </li>
                                <li class="nav-item d-none">
                                    <a class="nav-link " data-toggle="tab" href="#emp_apply_cghs" role="tab">CHGS</a>
                                </li>

                            </ul><!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="tabs-1" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="add-new-emp-form">
                                                <div class="row">
                                                    <div class="col">
                                                        <label class="font-weight-bold">Add Employee Data</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <!-- changes Aditya -->
                                                <div class="row">
                                                    <div class="col">
                                                    <div id="dd"></div>
                                                   
                                                    </div>
                                                    <div class="col">
                                                    <div id="ff"></div>
                                                    </div>
                                                      </div>
                                                <div class="row">
                                                            <div class="col">
                                                                <label>Individual Photo</label>
                                                                <input type="file" class="form-control" name="image" id="img" required/>
                                                            </div>
                                                            <div class="col">
                                                        
                                                                <label>Group Photo</label>
                                                                <input type="file" class="form-control" name="image1" id="img1" required/>
                                                            </div>
                                                            
                                                        </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Name</label>
                                                        <input type="text" name="empName" value="<?php echo e($data->name); ?>" class="form-control">
                                                    </div>

                                                    <div class="col">
                                                        <label>Date of Birth</label>
                                                        <input type="date" name="empDob" id="empDob"
                                                            class="form-control" value="<?php echo e($data->dob); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label>Gender</label>
                                                        <?php
                                                            $gender=array('M'=>"Male",'F'=>"Femail",'O'=>"Prefer Not To Say");
                                                        ?>
                                                        <select class="form-control" name="empGender">
                                                            <option value="0">Select</option>
                                                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($data->gender==$gd): ?>
                                                                <option value="<?php echo e($gd); ?>" selected><?php echo e($value); ?></option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($gd); ?>" ><?php echo e($value); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Employee ID</label>
                                                        <input type="text" name="empId" class="form-control" value="<?php echo e($data->emp_id); ?>" readonly>
                                                    </div>
                                                    <div class="col">
                                                        <label>Employee Type</label>
                                                        <select class="form-control" name="empType" value="<?php echo e($data->user_job_type); ?>">
                                                            <option value="0">Select</option>
                                                            <option value="1">Permanent</option>
                                                            <option value="2">Apprentice</option>
                                                        </select>
                                                    </div>
                                                    <div class="col">
                                                        <label>Grade </label>
                                                        <select class="form-control" name="empGrade" id="empGrade">
                                                            <option value="0">Select</option>
                                                            <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($data->grade==$gd->id): ?>
                                                                <option value="<?php echo e($gd->id); ?>" selected><?php echo e($gd->grade_name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($gd->id); ?>"><?php echo e($gd->grade_name); ?></option>
                                                            <?php endif; ?>
                                                                
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>

                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Date of Joining</label>
                                                        <input type="date" name="empDoj" id="empDoj"
                                                            class="form-control" value="<?php echo e($data->do_joining); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label>Date of Retirement</label>
                                                        <input type="date" name="empDort" id="empDort"
                                                            class="form-control" value="<?php echo e($data->do_retirement); ?>">
                                                    </div>
                                                    <div class="col">
                                                                <label>DOA</label>
                                                                <input type="date" name="doa" id="empDoa"
                                                                    class="form-control" value="<?php echo e($data->doa); ?>">
                                                            </div>


                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Job Type</label>
                                                        <?php
                                                            $gender=array('1'=>"Male",'2'=>"Femail");
                                                        ?>
                                                        <select class="form-control" name="empGender">
                                                            <option value="0">Select</option>
                                                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($data->gender==$gd): ?>
                                                                <option value="<?php echo e($gd); ?>" selected><?php echo e($value); ?></option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($gd); ?>" ><?php echo e($value); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                    </div>
                                                    <div class="col">
                                                        <label>Pension Plan</label>
                                                        <select class="form-control" name="pensionPlan">
                                                            <option value="0">Select</option>
                                                            <option value="GPF">GPF/OPS</option>
                                                            <option value="NPS">NPS</option>
                                                        </select>
                                                    </div>
                                                    <div class="col">
                                                        <label>GPF/OPS/NPS No.</label>
                                                        <input type="text" name="empGpf" class="form-control" value="<?php echo e($data->gpf_no); ?>">
                                                    </div>
                                               

                                                </div>
                                                <!-- Aditya modifiy -->
                                                <div class="row">
                                                            <div class="col">
                                                                <label>PAN No.</label>
                                                                <input type="text" name="empPan" class="form-control" value="<?php echo e($data->pan_no); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>Aadhar No.</label>
                                                                <input type="text" name="empAdhr" class="form-control" value="<?php echo e($data->aadhar_no); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>T No.</label>
                                                                <input type="text" name="emptNo" class="form-control" value="<?php echo e($data->t_no); ?>">
                                                            </div>
                                                        </div>
                                                         <div class="row">
                                                           <div class="col">
                                                              <label>Blood Group</label>
                                                                <?php
                                                            $gender=array('1'=>"Male",'2'=>"Femail");
                                                        ?>
                                                        <select class="form-control" name="empGender">
                                                            <option value="0">Select</option>
                                                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($data->gender==$gd): ?>
                                                                <option value="<?php echo e($gd); ?>" selected><?php echo e($value); ?></option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($gd); ?>" ><?php echo e($value); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                                    <!-- <option value="2"selected>B+</option>
                                                                    <option value="3">Ab+</option>
                                                                    <option value="1">O+</option>
                                                                    <option value="2">O-</option>
                                                                    <option value="3">A-</option>
                                                                    <option value="1">B-</option>
                                                                    <option value="2">AB-</option> -->
                                    
                                                                </select>
                                                                </div>
                                                                <div class="col">
                                                              <label>Religion</label>
                                                                <select class="form-control" name="empreli" value="<?php echo e($data->religion); ?>">
                                                                    <option value="0">Select</option>
                                                                    <option value="1">Hindu</option>
                                                                    <option value="2">Muslim</option>
                                                                    <option value="3">Sikh</option>
                                                                    <option value="1">Christianity</option>
                                                                     </select>
                                                            </div>
                                                              <div class="col">
                                                              <label>Add Category</label>
                                                                <select class="form-control" name="empcat" value="<?php echo e($data->add_cat); ?>">
                                                                    <option value="0">Select</option>
                                                                    <option value="1">SC</option>
                                                                    <option value="2">ST</option>
                                                                    <option value="3">OBC</option>
                                                                    <option value="4">General</option>
                                                                     </select>
                                                            </div>
                                                          </div>
                                                          <div class="row">
                                                            <div class="col-md-4">
                                                                <label>Promotion/MACP</label>
                                                                <input type="date" name="empPromo" class="form-control" value="<?php echo e($data->pro_macp); ?>">
                                                            </div>
                                                            <div class="col-md-4">
                                                                 <label>TOS.</label>
                                                                <input type="date" name="empTos" class="form-control" value="<?php echo e($data->tos); ?>">
                                                            </div>
                                                            <div class="row mx-2 mt-4">
                                                            <div class="col">
                                                            <div class="form-check">
                          
                                                        <input type="radio" class="form-check-input" name="empchk" value="Eihs" value="<?php echo e($data->cgh_ehs); ?>">
                                                        <label class="form-check-label mt-1">EIHS</label>
                                                           </div>
                                                            </div>
                                                          <div class="col ">
                                                          <div class="form-check">
                           
                                              <input type="radio" class="form-check-input" name="empchk" value="cghs" value="<?php echo e($data->cgh_ehs); ?>">
                                               <label class="form-check-label mt-1">CGHS </label>
                                                     </div>
                                                           </div>
                                                           </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <label>DA ON TPT</label>
                                                                <input type="text" name="empda" class="form-control" value="<?php echo e($data->da_on_tpt); ?>">
                                                            </div>
                                                          </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label>Remarks</label>
                                                                <textarea class="form-control" rows="5" name="empRemark" ><?php echo e($data->remark); ?></textarea>
                                                            </div>
                                                            
                                                    </div>
                                                    <div class="row mt-4">
                                                            <div class="col">
                                                                <label class="font-weight-bold">Type Of Leave.</label>
                                                                <hr>
                                                            </div>
                                                          </div>
                                                          <div class="row">
                                                            <div class="col">
                                                                <label>EL</label>
                                                                <input type="text" name="empEl" class="form-control" value="<?php echo e($data->el); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>CL</label>
                                                                <input type="text" name="empCl"  class="form-control" value="<?php echo e($data->cl); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>Commuted HPL</label>
                                                                <input type="text" name="empCommut"  class="form-control" value="<?php echo e($data->commmute_hpl); ?>">
                                                            </div>
                                                          </div>
                                                          <div class="row">
                                                            <div class="col">
                                                                <label>HPL</label>
                                                                <input type="text" name="empHpl"  class="form-control" value="<?php echo e($data->hpl); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>OTL/CompOFF</label>
                                                                <input type="text" name="empOtl"  class="form-control" value="<?php echo e($data->otl_comoff); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>EOL Without MC</label>
                                                                <input type="text" name="empEol"  class="form-control" value="<?php echo e($data->eol_without); ?>">
                                                            </div>
                                                          </div>
                                                          <div class="row">
                                                            <div class="col">
                                                                <label>CCL</label>
                                                                <input type="text" name="empCcl"  class="form-control" value="<?php echo e($data->ccl); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>Paternity Leave</label>
                                                                <input type="text" name="empPatnity"  class="form-control" value="<?php echo e($data->paternity_lev); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label>Maternity Leavell</label>
                                                                <input type="text" name="empMaternity" class="form-control" value="<?php echo e($data->maternity_lev); ?>">
                                                            </div>
                                                          </div>
                                                          <div class="row">
                                                            <div class="col-md-4">
                                                                <label>EOL With MC</label>
                                                                <input type="text" name="empEol" class="form-control" value="<?php echo e($data->eol_with_mc); ?>">
                                                            </div>
                                                          </div>
                                                <div class="row mt-4">
                                                    <div class="col">
                                                        <label class="font-weight-bold"> Pay Information</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Basic Pay </label>
                                                        <input type="text" name="empPay" id="empPay" value="<?php echo e($data->pay); ?>"
                                                            class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>TA/DA </label>
                                                        <input type="text" name="empPaytada" id="empPaytada"
                                                        value="<?php echo e($data->post->ta_da); ?>"class="form-control" readonly>
                                                    </div>
                                                    <div class="col">
                                                        <label>HRA </label>
                                                        <input type="text" name="empPayHra" id="empPayHra"
                                                        value="<?php echo e($data->post->hra); ?>" class="form-control" readonly>
                                                    </div>
                                                    <div class="col">
                                                        <label>TPT </label>
                                                        <input type="text" name="empPayTpt" id="empPayTpt"
                                                        value="<?php echo e($data->post->tpt); ?>" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Pers Pay </label>
                                                        <input type="text" name="empPayPersPay" id="empPayPersPay"
                                                        value="<?php echo e($data->post->pers_pay); ?>" class="form-control">
                                                    </div>
                                                    <div class="col ">
                                                        <label>Govt Perks </label>
                                                        <input type="text" name="empPaygprk" id="empPaygprk"
                                                        value="<?php echo e($data->post->govt_perks); ?>" class="form-control">
                                                    </div>
                                                    <div class="col ">
                                                        <label>Total Pay</label>
                                                        <input type="text" name="empPayTotal" id="empPayTotal"
                                                        value="" class="form-control" readonly>
                                                    </div>

                                                </div>
                                                <div class="row mt-4">
                                                    <div class="col">
                                                        <label class="font-weight-bold"> Contact Information</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Email</label>
                                                        <input type="email" name="empEmail" class="form-control" value="<?php echo e($data->email); ?>">
                                                    </div>

                                                    <div class="col">
                                                        <label>Mobile No.</label>
                                                        <input type="text" name="empMobNo" class="form-control" value="<?php echo e($data->primary_mob); ?>">
                                                    </div>
                                                    <div class="col">
                                                        <label>Alternative No.</label>
                                                        <input type="text" name="empAltNo" class="form-control" value="<?php echo e($data->alternat_mob); ?>">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Temporary Address</label>
                                                        <textarea name="empTempAddress" class="form-control" ><?php echo e($data->temp_address); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="row my-1">
                                                    <div class="col">
                                                        <label>Permanent Address</label>
                                                        <textarea name="empPerAddress" class="form-control" ><?php echo e($data->perm_address); ?></textarea>

                                                    </div>
                                                </div>
                                                <div class="row ">
                                                    <div class="col-md-2">
                                                        <label>Marriage Status</label>



                                                    </div>
                                                    <div class="col-md-3">

                                                        <input type="radio" name="empMrgStatus" value="single"
                                                            id="flexRadioDefault1" />Single

                                                        <input type="radio" name="empMrgStatus"
                                                                value="married"  />Married
                                                          
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <button type="Submit" class="btn btn-success">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>   
                                        
                                </div>
                                <div class="tab-pane " id="bank_details" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="add-emp-bank-details-form">
                                                        
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Employee Id</label><br>
                                                        <input type="text" class="form-control" name="empId" value="<?php echo e($id); ?>" readonly>

                                                    </div>
                                                    <div class="col">
                                                        <label>Acc Holder Name</label>
                                                        <input type="text" name="accHolder" id="empAccHolder"
                                                            class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Bank Name</label>
                                                        <input type="text" name="bankName" id="empBankName" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Account No.</label>
                                                        <input type="text" name="accNo" id="empAccNo" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>IFSC</label>
                                                        <input type="text" name="isfc" id="empIsfc" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Branch</label>
                                                        <input type="text" name="empBranch" id="empBranch" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <button type="Submit" class="btn btn-success">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <div class="card mt-1">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col">
                                                    <label class="font-weight-bold">Employee Bank Details</label>
                                                    <hr>
                                                </div>
                                            </div>
                                            
                                            <div class="row mt-3">
                                                <div class="col">
                                                    <table class="table table-bordered myTable " id="jsTable">
                                                        <thead>
                                                            <th class="text-center">S.No</th>
                                                            <th class="text-center">Bank Name</th>
                                                            <th class="text-center">Account Holder</th>
                                                            <th class="text-center">Account No.</th>
                                                            <th class="text-center">ISFC</th>
                                                            <th class="text-center">Action</th>
                                                            
                                                            
                                                        </thead>

                                                        <tbody class="text-center">
                                                            <?php
                                                                $i = 1;
                                                            ?>
                                                            <?php $__currentLoopData = $bankDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bDtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($i); ?></td>
                                                                    <td><?php echo e($bDtl->bank_name); ?></td>
                                                                    <td><?php echo e($bDtl->acc_holder); ?></td>
                                                                    <td><?php echo e($bDtl->acc_no); ?></td>
                                                                    <td><?php echo e($bDtl->bank_isfc); ?></td>
                                                                    <td>
                                                                        <a href="javascript:void(0)"
                                                                            class="text-danger deleteEmpBankData"
                                                                            data-id="<?php echo e($bDtl->id); ?>"><i class="fa fa-trash"
                                                                                aria-hidden="true"></i></a>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                        </tbody>


                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane " id="dependent_details" role="tabpanel">
                                    
                                    <div class="card mt-1">
                                        <div class="card-body">

                                            <form id="add-new-emp-dependant-form">
                                                <?php echo csrf_field(); ?>
                                                <div class="row ">
                                                    <div class="col">
                                                        <label class="font-weight-bold">Add Dependent Details</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Employee Id</label>
                                                        <input type="text" class="form-control" name="empId" value="<?php echo e($id); ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    
                                                    <div class="col">
                                                        <table class="table">
                                                            <tbody id="addDependData">
                                                                <tr>
                                                                    <td>
                                                                        <input type="text" name="dependentName[]"
                                                                            class="form-control"
                                                                            placeholder="Enter Dependent Name">
                                                                    </td>
                                                                    <td>
                                                                        <select class="form-control" name="rel[]">
                                                                            <option value="0">Select Relation</option>
                                                                            <option value="Father">Father</option>
                                                                            <option value="Mother">Mother</option>
                                                                            <option value="Wife">Wife</option>
                                                                            <option value="Husband">Husband</option>
                                                                            <option value="Child">Child</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" name="dependentIdNo[]"
                                                                            class="form-control"
                                                                            placeholder="Enter Dependent Id No.">
                                                                    </td>
                                                                    <td>
                                                                        <input type="file" name="dependentFile[]">
                                                                    </td>
                                                                    <td>
                                                                        <a href="javascript:void(0)"
                                                                            class="btn btn-outline-success w-100 text-center addDependField">Add
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>


                                                        </table>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <button type="Submit" class="btn btn-success">Add </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Dependent Name</th>
                                                    <th class="text-center">Dependent RelationShip</th>
                                                    <th class="text-center">Dependent ID</th>
                                                    <th class="text-center">Document</th>
                                                    <th class="text-center">Action</th>
                                                </thead>
                
                                                <tbody class="text-center">
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $dependntDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                        <tr>
                                                            <td><?php echo e($i); ?></td>
                                                            <td><?php echo e($d->dep_name); ?></td>
                                                            <td><?php echo e($d->relation); ?></td>
                                                            <td><?php echo e($d->id_no); ?></td>
                                                            <td><?php echo e($d->doc_path); ?></td>
                                                           
                               
                                                            <td>
                                                                <a href="javascript:void(0)" class="text-success " data-id="<?php echo e($d->id); ?>"><i
                                                                    class="fa fa-edit" aria-hidden="true"  ></i></a>
                                                                <a href="javascript:void(0)" class="text-danger " data-id="<?php echo e($d->id); ?>"><i
                                                                        class="fa fa-trash" aria-hidden="true"  ></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $i++;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                                </tbody>
                
                
                                            </table>
                                        </div>
                                    </div>


                                </div>
                                <div class="tab-pane " id="emp_skills" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="emp-skill-data">
                                                <div class="row">
                                                    <div class="col">
                                                        <label class="font-weight-bold">Add Skill</label>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row my-2">
                                                    <div class="col">
                                                        <label class="font-weight-bold">Employee Id</label>
                                                        <input type="text" class="form-control" name="empId" value="<?php echo e($id); ?>" readonly>
                                                    </div>
                                                    <div class="col">
                                                        <label class="font-weight-bold">Primary Technology Vertical</label>
                                                        <input type="text" name="empPrmySkill" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label class="font-weight-bold">Secondary Technology Vertical</label>
                                                        <input type="text" name="empScndSkill" class="form-control">
                                                    </div>

                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <input type="submit" class="btn btn-success" value="Add Skill">
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Primary Skill</th>
                                                    <th class="text-center">Secondary Skill</th>
                                                    <th class="text-center">Action</th>
                                                </thead>
                
                                                <tbody class="text-center">
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $skillDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                        <tr>
                                                            <td><?php echo e($i); ?></td>
                                                            <td><?php echo e($d->primary_skill); ?></td>
                                                            <td><?php echo e($d->secondary_skill); ?></td>
                                                            <td>
                                                                <a href="javascript:void(0)" class="text-success " data-id="<?php echo e($d->id); ?>"><i
                                                                    class="fa fa-edit" aria-hidden="true"  ></i></a>
                                                                <a href="javascript:void(0)" class="text-danger " data-id="<?php echo e($d->id); ?>"><i
                                                                        class="fa fa-trash" aria-hidden="true"  ></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $i++;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                                </tbody>
                
                
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane  " id="emp_job_history" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="add-emp-job-details-form">
                                                        
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Employee Id</label><br>
                                                        <input type="text" class="form-control" name="empId" value="<?php echo e($id); ?>" readonly>

                                                    </div>
                                                    <div class="col">
                                                        <label>Designation</label>
                                                        <input type="text" name="designation" id="designation" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Unit No.</label>
                                                        <input type="text" name="unitNo" id="UnitNo" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Unit Name</label>
                                                        <input type="text" name="unitName" id="unitName" class="form-control">
                                                    </div>
                                                    
                                                   
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Unit Incharge</label>
                                                        <input type="text" name="unitIncharge" id="unitIncharge" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Job Status</label>
                                                        <select class="form-control" name="job_status" id="job_status">
                                                            <option value='1'>Current Working</option>
                                                            <option value='0'>Previous Post</option>
                                                        </select>
                                                        
                                                    </div>
                                                    <div class="col prevDate d-none">
                                                        <label>From</label>
                                                        <input type="date" name="from_prev" class="form-control">
                                                    </div>

                                                    <div class="col prevDate d-none">
                                                        <label>To</label>
                                                        <input type="date" name="to_prev" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <button type="Submit" class="btn btn-success">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Emp ID</th>
                                                    <th class="text-center">Emp Name</th>
                                                    <th class="text-center">Designation</th>
                                                    <th class="text-center">Unit No</th>
                                                    <th class="text-center">Unit name</th>
                                                    <th class="text-center">Unit Incharge</th>
                                                    <th class="text-center">Job Status</th>
                                                    <th class="text-center">Action</th>
                                                </thead>
                
                                                <tbody class="text-center">
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $jobDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                        <tr>
                                                            <td><?php echo e($i); ?></td>
                                                            <td><?php echo e($d->emp_id); ?></td>
                                                            <td><?php echo e($d->empdetails->name); ?></td>
                                                            <td><?php echo e($d->designation); ?></td>
                                                            <td><?php echo e($d->unit_no); ?></td>
                                                            <td><?php echo e($d->unit_name); ?></td>
                                                            <td>
                                                              
                                                                   <?php echo e($d->unit_incharge_id); ?> 
                                                               
                                                            </td>
                                                            <td>
                                                                <?php if($d->unit_job_status==1): ?>
                                                                    <span class="text-success">Current Posting</span>
                                                                <?php else: ?>
                                                                <span class="text-dange">Previous Posting</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            
                               
                                                            <td>
                                                                <a href="javascript:void(0)" class="text-success " data-id="<?php echo e($d->id); ?>"><i
                                                                    class="fa fa-edit" aria-hidden="true"  ></i></a>
                                                                <a href="javascript:void(0)" class="text-danger " data-id="<?php echo e($d->id); ?>"><i
                                                                        class="fa fa-trash" aria-hidden="true"  ></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $i++;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                                </tbody>
                
                
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane " id="pf_details" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="add-emp-pf-details-form">
                                                        
                                                <div class="row">
                                                    <div class="col">
                                                        <label>Employee Id</label><br>
                                                        <input type="text" class="form-control" name="empId" value="<?php echo e($id); ?>" readonly>

                                                    </div>
                                                    
                                                    <div class="col">
                                                        <label>Account No.</label>
                                                        <input type="text" name="accNo" class="form-control">
                                                    </div>
                                                    <div class="col">
                                                        <label>Nominee</label>
                                                        <select class="form-control" name="nominee">
                                                            <option value="0">Select</option>
                                                            <?php $__currentLoopData = $dependntDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($dpd->id); ?>"><?php echo e($dpd->dep_name); ?> (<?php echo e($dpd->relation); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        
                                                    </div>
                                                   
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <hr>
                                                        <button type="Submit" class="btn btn-success">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Account</th>
                                                    <th class="text-center">Nominee</th>
                                                    
                                                    <th class="text-center">Action</th>
                                                </thead>
                
                                                <tbody class="text-center">
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $pfDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                        <tr>
                                                            <td><?php echo e($i); ?></td>
                                                            <td><?php echo e($d->pf_acc_no); ?></td>
                                                            <td> 
                                                                <?php if($d->nomineeDetails->dep_name): ?>
                                                                    <?php echo e($d->nomineeDetails->dep_name); ?> (<?php echo e($d->nomineeDetails->relation); ?>)
                                                                <?php else: ?>
                                                                    NA
                                                                <?php endif; ?>
                                                                
                                                            </td>
                                                            <td>
                                                                <a href="javascript:void(0)" class="text-success " data-id="<?php echo e($d->id); ?>"><i
                                                                    class="fa fa-edit" aria-hidden="true"  ></i></a>
                                                                <a href="javascript:void(0)" class="text-danger " data-id="<?php echo e($d->id); ?>"><i
                                                                        class="fa fa-trash" aria-hidden="true"  ></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $i++;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                                </tbody>
                
                
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane " id="emp_apply_cghs" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <form id="emp-cghs-data">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label class="font-weight-bold">CGHS Facility</label>
                                                       
                                                    </div>
                                                    <div class="col-md-2">
                                                        <input type="checkbox" value="1" name="isCghsTrue" id="isCghsTrue"> Apply For CGHS
                                                        
                                                    </div>
                                                </div>
                                                <div class="row d-none">
                                                    <div class="col">
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row my-2 cghsForm d-none">
                                                    <div class="col">
                                                        <label class="font-weight-bold">Employee Id</label>
                                                        <input type="text" class="form-control" name="empId" value="<?php echo e($id); ?>" readonly>
                                                    </div>

                                                  

                                                </div>
                                                <div class="row cghsForm d-none">
                                                    <div class="col">
                                                        <table class="table">
                                                            <thead>
                                                                <th>S.No</th>
                                                                <th>Dependent Name</th>
                                                                <th>Dependent D.O.B</th>
                                                                <th>Action</th>
                                                                
                                                            </thead>
                                                            <tbody id="addDependDataForCghs">

                                                                <tr>
                                                                    <td>1</td>
                                                                    <td>
                                                                        <select class="form-control" name="dependent[]">
                                                                            <option value="0">Select Dependent</option>
                                                                            <?php $__currentLoopData = $dependntDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->dep_name); ?> (<?php echo e($d->relation); ?>)</option>
                                                                                
                                                                                <?php
                                                                                    $i++;
                                                                                ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                          
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <input type="date" name="dob[]"
                                                                            class="form-control"
                                                                            placeholder="Enter Dependent Id No.">
                                                                    </td>
                                                                    <td>
                                                                        <a href="javascript:void(0)"
                                                                            class="btn btn-outline-success w-100 text-center addCGSHDependField">Add
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>


                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="row d-none">
                                                    <div class="col">
                                                        <hr>
                                                        <input type="submit" class="btn btn-success" value="Add Skill">
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card d-none">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Primary Skill</th>
                                                    <th class="text-center">Secondary Skill</th>
                                                    <th class="text-center">Action</th>
                                                </thead>
                
                                                <tbody class="text-center">
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $skillDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                        <tr>
                                                            <td><?php echo e($i); ?></td>
                                                            <td><?php echo e($d->primary_skill); ?></td>
                                                            <td><?php echo e($d->secondary_skill); ?></td>
                                                            <td>
                                                                <a href="javascript:void(0)" class="text-success " data-id="<?php echo e($d->id); ?>"><i
                                                                    class="fa fa-edit" aria-hidden="true"  ></i></a>
                                                                <a href="javascript:void(0)" class="text-danger " data-id="<?php echo e($d->id); ?>"><i
                                                                        class="fa fa-trash" aria-hidden="true"  ></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $i++;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                                </tbody>
                
                
                                            </table>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Adityahrms1\govt_hrms\govt_hrms\hrms\hrmsproject\resources\views/employee/emp_detailing.blade.php ENDPATH**/ ?>