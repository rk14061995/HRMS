@include('manager.layouts.header')

@yield('main')
@include('manager.layouts.footer')