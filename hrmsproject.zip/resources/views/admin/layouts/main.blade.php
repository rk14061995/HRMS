@include('admin.layouts.header')

@yield('main')
@include('admin.layouts.footer')