<div class="container-fluid">
                     <div class="footer">
                        <p>Copyright © 2022 Designed by Html.Design. All rights reserved.<br><br>
                           Developed By: <a href="https://greenusys.com/" style="color:blue;">Greenusys Technology</a>
                        </p>
                     </div>
                  </div>
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
      </div>

      
      <!-- jQuery -->
      <script src="frontend/js/jquery.min.js"></script>
      <script src="frontend/js/popper.min.js"></script>
      <script src="frontend/js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="frontend/js/animate.js"></script>
      <!-- select country -->
      <script src="frontend/js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="frontend/js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="frontend/js/Chart.min.js"></script>
      <script src="frontend/js/Chart.bundle.min.js"></script>
      <script src="frontend/js/utils.js"></script>
      <script src="frontend/js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="frontend/js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="frontend/js/custom.js"></script>
      <script src="frontend/js/chart_custom_style1.js"></script>
   </body>
</html>