@extends('admin.layouts.main')
               @section('main')
               <!-- end topbar -->
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>MedicalSheet Profile</h2>
                           </div>
                        </div>
                     </div>
                     
                    @endSection