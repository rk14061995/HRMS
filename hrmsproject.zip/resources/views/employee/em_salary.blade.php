@extends('employee.layouts.main')
@section('main')
    <!-- end topbar -->
    <!-- dashboard inner -->
    <div class="midde_cont mt-2">
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col text-center">
                    <div class="card">
                        <div class="card-body">
                            LTC Claim
                        </div>
                    </div>
                </div>
            </div>
            <div class="row my-1">
                <style>
                    input {
                        border-top-style: hidden;
                        border-right-style: hidden;
                        border-left-style: hidden;
                        border-bottom-style: groove;
                        /* background-color: #eee; */
                        }

                        .no-outline:focus {
                        outline: none;
                        }
                </style>
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="tab" href="#empl_list" role="tab">Employee List</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" data-toggle="tab" href="#emp_pay_roll" role="tab">Employee Monthly - Pay Roll</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" data-toggle="tab" href="#comm_pay_roll" role="tab">Commulative - Pay Roll</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" data-toggle="tab" href="#emp_pay_roll_summ" role="tab">Employee - Pay Roll(Summary) </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" data-toggle="tab" href="#comm_pay_roll_summ" role="tab">Commulative - Pay Roll(Summary) </a>
                                </li>


                            </ul><!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane " id="empl_list" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Employee Name</th>
                                                    <th class="text-center">Employee Id</th>
                                                    <th class="text-center">Basic Pay</th>
                                                    <th class="text-center">DA</th>
                                                    <th class="text-center">HRA</th>
                                                    <th class="text-center">TPT</th>
                                                    <th class="text-center">Pers Pay</th>
                                                    <th class="text-center">WA</th>
                                                    <th class="text-center">MISC</th>
                                                    {{-- <th class="text-center">Total</th> --}}
                                                </thead>

                                                <tbody class="text-center">
                                                    @php
                                                        $i = 1;
                                                    @endphp
                                                    @foreach ($employee as $emp)
                                                        <tr>
                                                            <td>{{$i}}</td>
                                                            <td><a href="javascript:void(0)" class="text-primary">{{$emp->name}}</a></td>
                                                            <td><a href="javascript:void(0)" class="text-primary">{{$emp->emp_id}}</a></td>
                                                            <td>{{ $emp->basic_pay}}</td>
                                                            <td>{{$emp->ta_da}}</td>
                                                            <td>{{$emp->hra}}</td>
                                                            <td>{{$emp->tpt}}</td>
                                                            <td>{{ $emp->pers_pay}}</td>
                                                            <td>{{ $emp->govt_perks}}</td>
                                                            <td></td>
                                                        </tr>
                                                        @php
                                                            $i++;
                                                        @endphp
                                                    @endforeach

                                                </tbody>


                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane " id="emp_pay_roll" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col tex-right">
                                                    <a href="javascript:printDiv()" class="text-primary"><i
                                                            class="fa fa-print" aria-hidden="true"></i> Print</a>
                                                </div>
                                            </div>
                                            <div class="row mt-3" id="DivIdToPrint">
                                                <style type="text/css" media="print">
                                                    @page { size: landscape; }
                                                    
                                                  </style>
                                                <div class="col">
                                                    <div class="row" >
                                                        
                                                        <div class="col-md-12" id="">
                                                            <div class="row">
                                                                <div class="col">
                                                                    <h3 style="text-align: center;"><u>STATION WORKSHOP EME, DELHI CANTT -10</u></h3>
                                                                    <h4><u>Pay Roll Of CIVILIANS (INDUSTRIAL) PERS</u></h4>
                                                                    <h6 style="text-align: end;">For the month : <u>{{date('M Y')}}</u><br>
                                                                        No of working days <u>: 24 ({{date('M Y',strtotime("-1 months"))}})</u></h6>
                                                                        
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col">
                                                                    <table class="text-center w-100" border="1" style="font-size:12px">
                                                                        <tr>
                                                                            <th colspan="5"></th>
                                                                            {{-- <th colspan="3"></th> --}}
                                                                            <th colspan="10">Entitlements</th>
                                                                            <th colspan="10">Deductions</th>
                                                                        </tr>
                                                        
                                                                        <tr>
                                                                            <td rowspan="3">S No.</td>
                                                        
                                                                            <td colspan="5">No.Trade. Name</td>
                                                                            <th rowspan="3" >BP<br> Level</th>
                                                                            <th rowspan="3" >DA <br>34%</th>
                                                                            <th rowspan="3" >HRA <br> 27%</th>
                                                                            <th rowspan="3" >TPT</th>
                                                                            <th rowspan="3" >Pers <br> Pay</th>
                                                                            <th rowspan="3" >WA</th>
                                                                            <th rowspan="3" >Misc</th>
                                                                            <th rowspan="3" >Total Pay</th>
                                                                            <th rowspan="3" >EOL(H</th>
                                                                            <th rowspan="3" >GPF</th>
                                                                            <th rowspan="3" >GPF<br>Ref</th>
                                                                            <th rowspan="3" >CGEIS</th>
                                                                            <th rowspan="3" >CGHS</th>
                                                                            <th rowspan="3" >F Adv</th>
                                                                            <th rowspan="3" >Rent <br> Rec</th>
                                                                            <th rowspan="3" >Misc<br>Ded</th>
                                                                            <th rowspan="3" >Tax<br> Ded</th>
                                                                            <th rowspan="3" >Total<br>Ded</th>
                                                                            <th rowspan="3" >Net Pay</th>
                                                                        </tr>
                                                        
                                                                        <tr>
                                                        
                                                                            <td>DOB</td>
                                                                            <td>GPF A/C</td>    
                                                                            <td>EOL(D)</td>
                                                                            <td>EOL(H)</td>
                                                                        </tr>
                                                        
                                                                        <tr>
                                                                            <td>DOA</td>
                                                                            <td>PAN NO</td>
                                                                            <td colspan="2">AADHAR NO</td>
                                                                        </tr>
                                                        
                                                                        <tr>
                                                                            <td> </td>
                                                                        </tr>
                                                        
                                                        
                                                        
                                                        
                                                        @php
                                                            $p=1;
                                                        @endphp
                                                                        @foreach ($employee as $empSal)
                                                                            <tr>
                                                                                <td rowspan="3">{{$p}}.</td>
                                                            
                                                                                <td colspan="5">T. No-{{$empSal->t_no}} VM (MCM) Sh {{$empSal->name}} (DOR {{date('d/m/Y',strtotime($empSal->do_retirement))}})</td>
                                                                                <th rowspan="2" >{{$empSal->basic_pay}}</th>
                                                                                <th rowspan="2" >{{$empSal->ta_da}}</th>
                                                                                <th rowspan="2" >{{$empSal->hra}} </th>
                                                                                <th rowspan="2" >{{$empSal->tpt}}</th>
                                                                                <th rowspan="2" >{{$empSal->pers_pay}}</th>
                                                                                <th rowspan="2" >{{$empSal->govt_perks}}</th>
                                                                                <th rowspan="2" >120</th>
                                                                                <th rowspan="2" >
                                                                                    {{$empSal->basic_pay + $empSal->ta_da + $empSal->hra + $empSal->tpt + $empSal->pers_pay}}
                                                                                </th>
                                                                                <th rowspan="2" >2578</th>
                                                                                <th rowspan="2" >25489</th>
                                                                                <th rowspan="2" >251875</th>
                                                                                <th rowspan="2" >24589</th>
                                                                                <th rowspan="2" >225561</th>
                                                                                <th rowspan="2" >25451</th>
                                                                                <th rowspan="2" >254586</th>
                                                                                <th rowspan="2" >588</th>
                                                                                <th rowspan="2" >326478</th>
                                                                                <th rowspan="2" >254689</th>
                                                                                <th rowspan="2" >24561</th>
                                                                            </tr>
                                                                            <tr>
                                                        
                                                                                <td>{{date('d/m/Y',strtotime($empSal->dob))}}</td>
                                                                                <td>{{$empSal->gpf_no}}</td>
                                                                                <td>0</td>
                                                                                <td>0</td>
                                                                            </tr>
                                                            
                                                                            <tr>
                                                                                <td>{{date('d/m/Y',strtotime($empSal->doa))}}</td>
                                                                                <td>{{$empSal->pan_no}}</td>
                                                                                <td colspan="2">{{$empSal->aadhar_no}}</td>
                                                                                <th colspan="22">Remarks: IT @ 5200/- (1)</th>
                                                                            </tr>
                                                                            @php
                                                                                $p++
                                                                            @endphp
                                                                        @endforeach
                                                        
                                                        
                                                                       
                                                        
                                                                        
                                                                        <tr>
                                                                            <td colspan="25"> Page Total 1</td>
                                                                        </tr>
                                                        
                                                        
                                                                    </table>
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="pagebreak"> </div>
                                                    
                                                </div>



                                                
                                                
                                                
                                                
                                                


                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="tab-pane active" id="comm_pay_roll" role="tabpanel">
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table table-bordered myTable ">
                                                <thead>
                                                    <th class="text-center">S.No</th>
                                                    <th class="text-center">Employee Name</th>
                                                    <th class="text-center">Employee Id</th>
                                                    <th class="text-center">Basic Pay</th>
                                                    <th class="text-center">DA</th>
                                                    <th class="text-center">HRA</th>
                                                    <th class="text-center">TPT</th>
                                                    <th class="text-center">Pers Pay</th>
                                                    <th class="text-center">WA</th>
                                                    <th class="text-center">MISC</th>
                                                    {{-- <th class="text-center">Total</th> --}}
                                                </thead>

                                                <tbody class="text-center">
                                                    @php
                                                        $i = 1;
                                                    @endphp
                                                    @foreach ($employee as $emp)
                                                        <tr>
                                                            <td>{{$i}}</td>
                                                            <td><a href="javascript:void(0)" class="text-primary">{{$emp->name}}</a></td>
                                                            <td><a href="javascript:void(0)" class="text-primary">{{$emp->emp_id}}</a></td>
                                                            <td>{{ $emp->basic_pay}}</td>
                                                            <td>{{$emp->ta_da}}</td>
                                                            <td>{{$emp->hra}}</td>
                                                            <td>{{$emp->tpt}}</td>
                                                            <td>{{ $emp->pers_pay}}</td>
                                                            <td>{{ $emp->govt_perks}}</td>
                                                            <td></td>
                                                        </tr>
                                                        @php
                                                            $i++;
                                                        @endphp
                                                    @endforeach

                                                </tbody>


                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
@endsection
