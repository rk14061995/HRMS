@include('employee.layouts.header')

@yield('main')

@include('employee.layouts.footer')